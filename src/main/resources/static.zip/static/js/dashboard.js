window.onload = function () {
    const email = localStorage.getItem("userEmail");

    if (!email) {
        console.error("No email found in localStorage. Redirecting to login.");
        window.location.href = "login.html";
        return;
    }

    fetch(`http://localhost:8080/api/users/${email}`)
        .then(response => {
            if (!response.ok) {
                throw new Error("Failed to fetch user");
            }
            return response.json();
        })
        .then(data => {
            const name = data.name || "User";
            document.getElementById("username").textContent = name;

            const userGreeting = document.querySelector(".user-greeting");
            if (userGreeting) {
                userGreeting.innerHTML = `Hi, ${name} 👋`;
            }
        })
        .catch(error => {
            console.error("Error fetching user:", error);
            window.location.href = "login.html";
        });
};
